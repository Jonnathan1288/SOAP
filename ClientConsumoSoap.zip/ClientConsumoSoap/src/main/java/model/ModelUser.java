/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import sv.Servicios;
import sv.Servicios_Service;

/**
 *
 * @author DELL
 */
public class ModelUser extends User {
    //Map<String, UserInfo> userMap = new HashMap<String, UserInfo>();
//como usar un map para almacenar el usuario, password y valor en java

    Servicios_Service servicio = new Servicios_Service();
    Servicios cliente = servicio.getServiciosPort();
    
    public String SingIn(String user, String password){
        String userResponse = cliente.signin(user, password);
        return userResponse;
    }
    
    public Boolean SingUp(String user, String password, int saldo){
        boolean successful = cliente.signup(user, password, saldo);
        return true;
    }
    
    public Boolean update(String user, int bank_balance){
        boolean update_successful = cliente.update(user, bank_balance);
        return update_successful;
    }

}
