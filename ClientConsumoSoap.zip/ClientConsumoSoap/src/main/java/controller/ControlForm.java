/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.swing.JOptionPane;
import model.ModelUser;
import view.FormAcces;
import view.FormDepRet;
import view.FormRecord;

/**
 *
 * @author DELL
 */
public class ControlForm {

    private FormAcces viewFormAcces;
    private FormRecord viewRecord;
    private FormDepRet viewDepRet;
    private ModelUser modelUser;

    public ControlForm(FormAcces viewFormAcces, FormRecord viewRecord, FormDepRet viewDepRet, ModelUser modelUser) {
        this.viewFormAcces = viewFormAcces;
        this.viewRecord = viewRecord;
        this.viewDepRet = viewDepRet;
        this.modelUser = modelUser;
        view();
    }

    //View of sign in
    private void view() {
        viewFormAcces.setVisible(true);
        controlBtns();
    }

    private void controlBtns() {
        viewFormAcces.getBtnSingIn().addActionListener(l -> SingIn());
        viewFormAcces.getBtnSingUp().addActionListener(l -> SingUp());

        //
        viewRecord.getBtnCreateR().addActionListener(l -> creteUser());

        //
        viewDepRet.getBtnConfirmOperation().addActionListener(l -> IngresoRetiro());

    }

    private void SingIn() {
        String user = viewFormAcces.getTxtUserFormA().getText();
        String password = viewFormAcces.getTxtPasswordA().getText();

        String userHere = modelUser.SingIn(user, password);
        if (userHere.equals("User Don't exit..")) {
            JOptionPane.showMessageDialog(null, "No hay user");
        } else {
            viewDepRet.setVisible(true);
            viewFormAcces.setVisible(false);
            String[] userDetails = userHere.split("/");
            String userResponse = userDetails[0];
            String passwordResponse = userDetails[1];
            int bank_BalanceResponse = Integer.parseInt(userDetails[2]);

            viewDepRet.getLblNameUser().setText(userResponse);
            viewDepRet.getLblSaldoUser().setText("" + bank_BalanceResponse);

            JOptionPane.showMessageDialog(null, "" + userHere);
        }

    }

    private void SingUp() {
        viewFormAcces.setVisible(false);
        viewRecord.setVisible(true);
    }

    private void creteUser() {
        String user = viewRecord.getTxtUserR().getText();
        String password = viewRecord.getTxtPasswordR().getText();
        String repeat_password = viewRecord.getTxtRepeatPasswordR().getText();
        String bank_balance = viewRecord.getTxtSaldo().getText();

        if (password.equals(repeat_password)) {
            if (modelUser.SingUp(user, password, Integer.parseInt(bank_balance))) {
                JOptionPane.showMessageDialog(viewRecord, "Create successful");
            } else {
                JOptionPane.showMessageDialog(viewRecord, "Error the user exit");
            }

        } else {
            JOptionPane.showMessageDialog(viewRecord, "The password it don´t same");

        }
    }

    private void IngresoRetiro() {
        String user = viewDepRet.getLblNameUser().getText();
        int bank_balance = Integer.parseInt(viewDepRet.getLblSaldoUser().getText());

        if (viewDepRet.getComboTipoOperacion().getSelectedItem().toString().equalsIgnoreCase("Seleccione")) {
            JOptionPane.showMessageDialog(viewDepRet, "Seleccione el tipo de retiro");
        } else {
            if (viewDepRet.getComboTipoOperacion().getSelectedItem().toString().equalsIgnoreCase("Depocito")) {
                int more_bank_balance = Integer.parseInt(viewDepRet.getTxtValorResta().getText());

                int new_bank_balance = bank_balance + more_bank_balance;

                if (modelUser.update(user, new_bank_balance)) {
                    viewDepRet.getLblSaldoUser().setText("" + new_bank_balance);
                } else {
                    JOptionPane.showMessageDialog(viewDepRet, "Eroor al actualizar");
                }

            } else if (viewDepRet.getComboTipoOperacion().getSelectedItem().toString().equalsIgnoreCase("Retiro")) {
                int putOff_bank_balance = Integer.parseInt(viewDepRet.getTxtValorResta().getText());

                if (putOff_bank_balance > bank_balance) {
                    JOptionPane.showMessageDialog(viewDepRet, "No se puede quitar más dinero al actual..");
                } else {
                    
                    int new_bank_balance = bank_balance - putOff_bank_balance;
                    
                    if (modelUser.update(user, new_bank_balance)) {
                        viewDepRet.getLblSaldoUser().setText("" + new_bank_balance);
                    } else {
                        JOptionPane.showMessageDialog(viewDepRet, "Eroor al actualizar");
                    }

                }
            }
        }
    }
}
